import copy
import csv
import json
import scrapy
import requests

class Airbp(scrapy.Spider):
    name = 'Airbp'
    # custom_settings = {
    #     'FEED_URI': 'outputs/Airbp_Sample.csv',
    #     'FEED_FORMAT': 'csv',
    #     'FEED_EXPORT_ENCODING': 'utf-8',}
    # url = "https://apollo.myairbp.bpglobal.com/graphql"
    # payload = json.dumps({
    #         "operationName": "FuelPrice",
    #         "variables": {
    #             "currencyCode": "EUR",
    #             "grn": "1214800",
    #             "locationCode": location_code,
    #             "pricingDate": "20240128",
    #             "uomCode": "L"
    #         },
    #         "query": "query FuelPrice($currencyCode: String!, $grn: String!, $locationCode: String!, $pricingDate: String!, $uomCode: String!) {\n  fuelPrice(currencyCode: $currencyCode, grn: $grn, locationCode: $locationCode, pricingDate: $pricingDate, uomCode: $uomCode) {\n    errors\n    reason\n    status\n    grn\n    customerType\n    prices {\n      airportInformation {\n        fuelProvider\n        fuelProviderEmail\n        fuelProviderFax\n        fuelProviderOpeningHours\n        fuelProviderTelephone\n        isFuelAvailableOutOfHours\n        preAdvisedFlightInfo\n        airBPCustomerServicePhone\n        airBPCustomerServiceEmail\n        __typename\n      }\n      country\n      countryName\n      deliveryArea\n      deliveryPointUid\n      fuelProvider\n      fuelType\n      iata\n      icao\n      location\n      locationName\n      price {\n        bandPriceDesc\n        currency\n        currencyConverted\n        effectiveFrom\n        effectiveTo\n        isFallback\n        isISP\n        mandatoryConditionalFixed\n        mandatoryConditionalVariable\n        mandatoryFixed\n        mandatoryFixedCurrency\n        mandatoryFixedUOM\n        mandatoryVariable\n        mandatoryVariableCurrency\n        mandatoryVariableUOM\n        netPriceConverted\n        priceBasisConverted\n        priceDiffConverted\n        pricingBasis\n        totalPrice\n        unitOfMeasurement\n        __typename\n      }\n      product\n      taxesAndFees {\n        compulsory {\n          aviationType\n          chargeType\n          currency\n          group\n          name\n          unitOfMeasurement\n          value\n          __typename\n        }\n        conditional {\n          aviationType\n          chargeType\n          currency\n          group\n          name\n          unitOfMeasurement\n          value\n          __typename\n        }\n        deliveryType\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"
    #     })
    # headers = {
    #     'authority': 'apollo.myairbp.bpglobal.com',
    #     'accept': '*/*',
    #     'accept-language': 'en-US,en;q=0.9,ur;q=0.8,nl;q=0.7',
    #     'content-type': 'application/json',
    #     'cookie': 'sessionHeadersource=a8f22a24d1324d3ed64158bed41c94dc%2F0e1k3j1xvz4r%2F27ece32d1fcca3ca; token=b49b9bc2c8626aa30cc7c0f9924c2068%2F03oavbrft604%2F7cbb6a86fcd3dac75a1c0614800e52cdbf0de88746481471ec191017244c8830db9d2af534a4eab3560f367e46f4e727b091bf6c15cbc6f9b31fb09d56412dccfb7d6fb9d2ad9368ccc91a457583d8ae80704ffc87bc95d5a1685e630ce699e15d1e5066205ecf9bc24d4a8503ceb85283ad84b304c48717b90f955ae58b44f24fdc53a49bb5040077daf84e146a758043b7e7feb9148cb0b26f11ab74b42256e1c4f9a81b4a736457d84dd486cf64fe1e451f988450e4cf5d282bc711dc3639f338c792629bcc4c51d6ffa030a9f31009c8ecea713a8fa70e97b27eac9e3d8aa96b0fb7c4c10df5a6c80baf16a930a9520f9c1c8928d75ba3caca11be68b81bc75163b0046c614ffe8a28b0d9e860f119c1aa05c90c270677a977b503f5aa97043b213274a499eabc8f6bf6dc2c2a133efdf92e99ca7b5efd75b687a466203ab780bee9f4c9c3bfd2a289ab63e6503718b3516078f828f24e6a6e5aa840227c6c8f08fd6ecbfd586efb1ad2306669f617416232ba6fbd30fc228d4686dc9eed5c40bd612bc12fe4dcb4802a1a6e030bdea3570b583663222724f03ad76117963d58341af5409d98baa44a71a976f3568f45ca02cc6728ada25cde450551cc353cf7062e3bfe2a271ec59e2797f4119636a3f46d512d02e6d6d3b08beddf297b6d66d438203cf6ae5766625a9262383673f228183b0a61d4bd8f1da5b5c4354a8c1fa57813cc39503f2c35c147f40e3fae31fb9aa9e2a5fafff2a21dee7d40cc9942ca0ed2969cc19741df8f7df6d1ac13ad97f63f81168a133940646fe281e78dcd209da59b4bc5aaf867cdfc02d6d40f048f7faa5f2e52392986089e42f6795e0814b57fe3f9af7624f401660001f78fd3ac1b79ba814b2a65d034f3757a2aea4d67cc8ad7471bb4d19b2b3214045502ae3b8e129faaed924e07bc7e2b7f542028e9a48fc52c2f33fc7c2d19191397a787ffb07e733fa93043b836fcafa32e5c6427327a9ba6a125a79137c0f5c586588bfc40cf6f3ca2473a7e8f5601bb85a85e32549b058c15e9dd076aa125b026f2329259a7fd8a51079562333783ea803a849d816853ba958fb1730213439a642893c10a3c363573fbeb040c186864e725c098390b6ca752b22e437aba2d0fb00fc7e9c235bb26fb947bc024fb16fac57c222e261ee30d7c29e04c93671007521233a2407f061f1518729260c27e62dfe74be057bbd16752d1f6b213a9a9650d622f8e0339c0c6be6512c6f5953d4b176686971509ca34746ce18082b25ee976529329054c7ad02fa156baa8a358d6da7e491bb8400a89f41839e349dfc6ea473489c7983d9e9ab9ac6f96516c16c54c1120edad0beafedac164cc3f916f82c400f4f2b588d07911cd2c94ce1bd01ce439f0ede1f55131023502d2705ef70643961fb3df8adfcf938d238aa5b344bb9691441bbfb03eeb5c0f00068de272cf74267f22d56a8a4b15f0bb1b1f8cd626531f006160632f0d28c5b3c77caf99467fff0adf2641d6aefde9786dc1285371ec00678d10dba760dd4b4eb3de3be5ec25e5ecd29f3052c8bb3f24cabf2bf2ffb56fc9ec919d8af9952f20db4200fcc9aaf0d9fdcbf5852db29505f5003eb0a8010a030d26f5297336481d6c854b4009057c6c5235ffbb8ee34eb2647f9c72ae6db7abd56be46408c9b5c6eb3c7e6673ecd0913fc52d5136e6ce02c3f5741587449c3b524b2b7b40fa604ed7aa9f1dab0fc5c7c1074d80906eeddcd9fd527cac88ff868a3bb14d98f645264ccd7bbb651895bb2e6f7671c44af06d0f0cea74c179cb0e1bb84630ce6266522372f6f258f30234ea3c5b0a828b714a5b38f8db997cfe70161eee14712676295ceaf00c907787cc94155b499e1478bd8c54c04e804181bac547945c93db364fb38762; id_token=d67ffecdf7c2c8769762508aa9fb8f5a%2F01gez8argiyp%2Fd475cbc13815593557bbc89b7b2d4e1d91065e3b062fbd467c3f222d9ef65b57091591830bb022b96f9f002dc72f7871eff41add7c94ab7a8d9c5c8ec8e93d82fad0c967b957117d02381b5a9fab3ca07e57ed620274d2528e15bcd0324a1e594aa8dc6c4cf9a9f0d63edfaec5b4737213fd7842876d305b8208cb5b1fde72d7f83d0942a02e680498e2c52b03db5b2d1802bcecfa18245e506044711bf82f8c5ad373f5f07f704f75100678ad9fb297accd3ea0948932a2fbc29834feb2e47b6bb7c0f782b890d8c41c07501abf4b40e682b3bc8613222df9c095517fb08fc00a48032a6ad580a1d3d451dc660eeb98e168471451fbf1b3b9f8a2b9b7d8ffbf42a14e5c8096f80b108340b51a5cc8fde0123d9be8f29f4a63c3f953a6b8d3eedb78fd7067b4e48c43b77bb64b656937291307025d9af7eb23dde361a70806c3b66d294ff00ee32e7b18dd94f113f88ada5881e91b3eacce180d86077908114e1e675a91a0bbfa4267e28e611947185bfec909092e91dfdf08e59b977ab437b5d5627a6f4ce71b2c37f36ccae677ec468b07205ae3df8528ced5ec7ca846032d0d9073f90956d73fbe718d22298182cb3646392b7391d28ea4ba208bcfb8f2afac1536209c7cb4d39d9d80117a7905be9c8f0758c770c1d9c746685dd47e7a399bde1e818de2d63052b8f91f1d29c291e18b6d070c60657af93234f499952033d6dfc2dace33b7f2cf86107ac37f2fef7fa7aba4c1b5e8eb14b45ad07cc09f2f55409ab5934df7a4898ece1fc9047dff5a6023860006296cb963d4d0dec6a959cf2cbd5aef78c31ba58eec774d42f30b613a72a70f793556271b9ecfaa97486c7e5f5d1591f36f36e1e95d823410594e974c965c5fa7a7397aab227bbb05e2de8f098074173004cc7f34a8af750636c73570a3302caa1007735b48a8a44453a06a0894efcdaed542ee003d835db843417be47dbce155bf8a3af3082b8bde7aad44ca17bce4383fa937401bb71cba489abb63adedb1ea60f2349aa7ba99ade8ead4d1c897cae5a5aa17512039b06b69b1f9dcd8fa97693c9fd2f405496f4716237f579ef4383fad49c25ece819dd3c5c25056603af200107eeee4632b19e014ee2afebec14890eaff29cdfd629a6963a70861ca5cc5b11ec3a05f752b2c1a63f7bf7249f2e1932317b5ccd06fea83d76db8d34b6c4572f31154d413df612431c94763372d2505abf88b44ef6273ab9106556a1039122998c0a2a6dccd0f0c333a02881eb316f7a20530f1c6d5ce12ed1527e6950f28868c4c47e713c2190fbf2dc977422d3b55d478cbdaee44828c55ab84cc8b074c220eb0f2cc912fa1ce56d8e3103d934c24e1a3f8cf8d5edce838b7d349e583eddfcef0e5784f85482571eb82036fd19e0f0cd6c6c9b28a6d0dc46dfb0800b06eeb08a59e203c43597d91ec322c357375168d3d4ec95237903814427b104750ba084afca3bec32ccf4f057937e99e1d1843b245f31d831868c380feaf0e04e54716de96cf6b3114c5c57678f96a16a396836be1e44388029f694107a551f144afd36a05c7ac31fe3aa97dab5b3b33113bca6149586765f21d8f1ec7090ff444daf5f41322dd9eee83a5b5ef5aedeb3f65676305410f044e69001fdde928ae1a0d1f77f8ee37aba4fa2a0a68d3d49076e7bc612bfc79052cd901dee6b94b7e49d56bf2aba24cb03c10130c0e50e8cf1116635df10c1f5874c339e8ea712a40654118110992986b84ca63ca15d25d00ac467917fa57e00f2dcf9e12933ae1b5bcaab2abb2c845382ddac22f66f322b5d463b4d518a83c1f9c12f35740664e0553714ca47cecd3174180c6da6f4e04fee9c28569c324; _ga=GA1.1.1049686179.1706445192; _ga_MJH66TPRNJ=GS1.1.1706445192.1.1.1706445231.0.0.0',
    #     'origin': 'https://myairbp.bpglobal.com',
    #     'referer': 'https://myairbp.bpglobal.com/',
    #     'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
    #     'sec-ch-ua-mobile': '?0',
    #     'sec-ch-ua-platform': '"Windows"',
    #     'sec-fetch-dest': 'empty',
    #     'sec-fetch-mode': 'cors',
    #     'sec-fetch-site': 'same-site',
    #     'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    #     'x-uniquerequestid': 'ce505e44-e961-4b99-95f4-8ba0d1dfb3bf'
    # }

    def start_requests(self):
        with open('inputs/test_JSON(2).json', 'r') as file:
            data = json.load(file)

        for element in data[0]['data']['fuelPrice']['prices']:
            if isinstance(element, dict):
                item = dict()
                item['GRN'] = data[0]['data']['fuelPrice']['grn']
                item['Airport'] = element.get('countryName') + ' , ' + element.get('locationName')
                item['IATA'] = element.get('iata')
                item['ICAO'] = element.get('icao')
                item['Fuel Type'] = element.get('fuelType')
                item['Effective From'] = element.get('price').get('effectiveFrom')
                item['Valid Until'] = element.get('price').get('effectiveTo')
                item['Delivery Area'] = element.get('deliveryArea')
                item['Into Plane Provider'] = element.get('fuelProvider')
                item['Pricing Basis'] = element.get('price').get('pricingBasis')
                item['Total Fuel Price (EUR/LT)'] = element.get('price').get('totalPrice')
                item['Single Fixed Charges (EUR/operation)'] = element.get('price').get('mandatoryFixed')

                # Calculate price for 150 & 300 liters
                price_for_150ltr = self.calculate_price(element, 150)
                price_for_300ltr = self.calculate_price(element, 300)

                # Add results to the 'item' dictionary
                item['Price for 150 Ltr Fuel (EUR)'] = price_for_150ltr
                item['Price for 300 Ltr Fuel (EUR)'] = price_for_300ltr

                csv_file = 'output/Airbp_updated_Sample(LPFR).csv'
                with open(csv_file, 'w', newline='') as file:
                    csv_writer = csv.DictWriter(file, fieldnames=item.keys())
                    csv_writer.writeheader()
                    csv_writer.writerow(item)

        yield scrapy.Request(url='https://example.com/', callback=self.parse)

    def parse(self, response):
        pass

    def calculate_price(self, element, volume):
        price = (volume * float(element.get('price').get('totalPrice'))) + float(element.get('price').get('mandatoryFixed'))
        price_before_tax = price

        # Process compulsory taxes and fees
        compulsory = element.get('taxesAndFees').get('compulsory')
        for comp in compulsory:
            if comp.get('chargeType') == 'Variable':
                price = price + (float(comp.get('value')) * volume)
            elif comp.get('chargeType') == 'Fixed':
                price = price + float(comp.get('value'))
            elif comp.get('chargeType') == 'Percentage':
                price = price_before_tax + (price_before_tax * float(comp.get('value')))

        # Process conditional taxes and fees
        conditional = element.get('taxesAndFees').get('conditional')
        for cond in conditional:
            if cond.get('chargeType') == 'Variable':
                price = price + (float(cond.get('value')) * volume)
            elif cond.get('chargeType') == 'Fixed':
                price = price + float(cond.get('value'))
            elif cond.get('chargeType') == 'Percentage':
                price = price_before_tax + (price_before_tax * float(cond.get('value')))

        return round(price, 2)

